const vegetables = [
    {
      name: "Carrots",
      description: "Carrots are a root vegetable that are rich in vitamin A and fiber.",
      imageFile: "carrots.jpg",
    },
    {
      name: "Spinach",
      description: "Spinach is a leafy green vegetable that is a good source of iron and vitamin C.",
      imageFile: "spinach.jpg",
    },
    {
      name: "Broccoli",
      description: "Broccoli is a cruciferous vegetable that is high in vitamin K and fiber.",
      imageFile: "broccoli.jpg",
    },
    {
      name: "Tomatoes",
      description: "Tomatoes are a fruit that are commonly used as a vegetable in cooking. They are a good source of vitamin C and lycopene.",
      imageFile: "tomatoes.jpg",
    },
    {
      name: "Bell Peppers",
      description: "Bell peppers are a sweet pepper that are available in a variety of colors, including green, red, yellow, and orange. This vegetable are a good source of vitamin C.",
      imageFile: "bell-peppers.jpg",
    },
    {
      name: "Garlic",
      description: "Garlic is a strongly flavored and aromatic vegetable that is commonly used in cooking. It is known for its potential health benefits, including reducing the risk of certain types of cancer and lowering cholesterol levels.",
      imageFile: "garlic.jpg",
    }
  ];

//---------------

  const stp_word = ["i","me","my","myself","we","our","ours","ourselves","you","your","yours","yourself","yourselves","he","him","his",
"himself","she","her","hers","herself","it","its","itself","they","them","their","theirs","themselves","what","which","who","whom",
"this","that","these","those","am","is","are","was","were","be","been","being","have","has","had","having","do","does","did","doing",
"a","an","the","and","but","if","or","because","as","until","while","of","at","by","for","with","about","against","between","into",
"through","during","before","after","above","below","to","from","up","down","in","out","on","off","over","under","again","further",
"then","once","here","there","when","where","why","how","all","any","both","each","few","more","most","other","some","such","no",
"nor","not","only","own","same","so","than","too","very","s","t","can","will","just","don","should","now" ];

//split word from description --> check stop_word and create tags to use for search
const extractTags = (description) => {
  const words = description.toLowerCase().split(" ");
  const filteredWords = words.filter((word) => !stp_word.includes(word));
  const uniqueTags = new Set(filteredWords);
  return Array.from(uniqueTags);
};

for (let i = 0; i < vegetables.length; i++) {
  const tags = extractTags(vegetables[i].description);
  vegetables[i].tags = tags;
}

console.log(vegetables);

//-----------

  // Function to render the search results
  function renderResults(results) {
    const searchContainer = document.getElementById("search-container");
    searchContainer.innerHTML = "";
  
    results.forEach((vegetable) => {
      const div = document.createElement("div");
      div.classList.add("vegetable");
  
      const img = document.createElement("img");
      img.src = vegetable.imageFile;
      div.appendChild(img);
  
      const h2 = document.createElement("h2");
      h2.textContent = vegetable.name;
      div.appendChild(h2);
  
      const p = document.createElement("p");
      p.textContent = vegetable.description;
      div.appendChild(p);
  
      searchContainer.appendChild(div);
    });
  }
  
  // Function to handle the search
  function handleSearch() {
    const input = document.getElementById("search-input").value.toLowerCase();
  
    const results = vegetables.filter((vegetable) => {
      return vegetable.tags.some((tag) => {
        return tag.includes(input);
      });
    });
  
    renderResults(results);
  }
  
  // Attach the search button click handler
  const searchButton = document.getElementById("search-button");
  searchButton.addEventListener("click", handleSearch);
